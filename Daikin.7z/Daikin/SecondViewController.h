//
//  SecondViewController.h
//  Daikin
//
//  Created by 周建政 on 16/9/26.
//  Copyright © 2016年 周建政. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *ssidLabel;
@property (weak, nonatomic) IBOutlet UITextField *_pwdTextView;


@property (weak, nonatomic) IBOutlet UITextField *_taskResultCountTextView;
@property (weak, nonatomic) IBOutlet UIButton *_confirmCancelBtn;
@property (weak, nonatomic) IBOutlet UISwitch *_isSsidHiddenSwitch;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *_spinner;

@end
