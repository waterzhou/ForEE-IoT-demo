//
//  AppDelegate.h
//  Daikin
//
//  Created by 周建政 on 16/9/26.
//  Copyright © 2016年 周建政. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

